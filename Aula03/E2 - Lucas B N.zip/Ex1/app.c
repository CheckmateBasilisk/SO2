#include<stdio.h>

extern int f ();

int main (){
    printf("%d\n", f());

    return 0;
}
