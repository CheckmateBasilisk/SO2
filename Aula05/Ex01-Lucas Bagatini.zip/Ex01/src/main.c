#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>

#include<my_shell.h>

int main(int argc, char *argv[]){
    return my_shell();
}
