#ifndef __MY_SHELL_H__
#define __MY_SHELL_H__

int print_shell(char *, char *, char *);
int my_shell();
int spawn(char* , char** );
int run_cmd(char *);

#endif
